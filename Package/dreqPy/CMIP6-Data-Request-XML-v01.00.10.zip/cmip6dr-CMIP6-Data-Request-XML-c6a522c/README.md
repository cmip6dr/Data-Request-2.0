# CMIP6-Data-Request-XML
The Data Request XML and XSD documents.
